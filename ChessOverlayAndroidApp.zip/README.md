# Chess Engine Overlay — Проект для Android Studio (Android 10 - 16)

Этот проект представляет собой нативное Android-приложение оверлея поверх шахматных игр с поддержкой скачивания любых UCI движков (Stockfish, Komodo и др.) и авто-ходом.

## Как собрать APK:

### Способ 1: Через Android Studio
1. Скачайте и распакуйте данный ZIP-архив.
2. Откройте **Android Studio** (версии Flamingo, Hedgehog, Iguana, Koala, Ladybug или новее).
3. Выберите **File -> Open...** и укажите распакованную папку `ChessOverlayAndroidApp`.
4. Дождитесь завершения Gradle Sync (Android Studio сама подтянет нужные SDK компоненты).
5. В верхнем меню выберите **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.
6. Готовый APK файл будет сгенерирован по пути:
   `app/build/outputs/apk/debug/app-debug.apk`.

### Способ 2: Через командную строку (Gradle Wrapper)
```bash
./gradlew assembleDebug
```
(для Windows: `gradlew.bat assembleDebug`)

---

## Архитектура модулей проекта:

- **`MainActivity.kt`**: Стартовый экран с проверкой и запросом системных разрешений.
- **`FloatingOverlayService.kt`**: Сервис плавающего поверх всех приложений окна (`TYPE_APPLICATION_OVERLAY`) с возможностью свободного перемещения пальцем по экрану и отображения рекомендаций хода.
- **`engine/ChessEngineManager.kt`**: Менеджер шахматных движков. Скачивает ARM64 бинарники движков (Stockfish 17, Dragon by Komodo), делает `chmod +x`, запускает через `ProcessBuilder` и взаимодействует по протоколу UCI (`stdin`/`stdout`).
- **`input/AutoPlayAccessibilityService.kt`**: Служба специальных возможностей, выполняющая программные жесты нажатия и перетаскивания фигур (`dispatchGesture`) на координатах доски в вашей шахматной игре.
- **`vision/ChessVisionScanner.kt`**: Модуль вычисления экранных координат клеток доски (от `a1` до `h8`).

---

## Системные требования:
- **Android**: от Android 10 (API 29) до Android 16 (API 35/36).
- **Архитектура процессора**: arm64-v8a, armeabi-v7a, x86_64.
- **Java**: JDK 17+.
