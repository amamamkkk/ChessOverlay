package com.mychess.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.mychess.overlay.engine.ChessEngineManager
import com.mychess.overlay.input.AutoPlayAccessibilityService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class FloatingOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var overlayView: View
    private lateinit var params: WindowManager.LayoutParams

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var engineManager: ChessEngineManager

    private var isAutoPlayActive = false
    private var currentBestMove: String = "e2e4"

    override fun onCreate() {
        super.onCreate()
        startAsForeground()

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        overlayView = LayoutInflater.from(this).inflate(R.layout.layout_overlay_hud, null)

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 80
            y = 180
        }

        setupDragListener()
        setupUIControls()

        engineManager = ChessEngineManager(this)
        serviceScope.launch {
            engineManager.startEngine("stockfish_arm64")
        }

        windowManager.addView(overlayView, params)
    }

    private fun startAsForeground() {
        val channelId = "chess_overlay_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Chess Overlay Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Шахматный оверлей активен")
            .setContentText("Анализ движка поверх вашей игры")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .build()

        startForeground(1001, notification)
    }

    private fun setupDragListener() {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        overlayView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(overlayView, params)
                    true
                }
                else -> false
            }
        }
    }

    private fun setupUIControls() {
        val btnClose = overlayView.findViewById<ImageButton>(R.id.btnCloseOverlay)
        val btnAutoPlay = overlayView.findViewById<Button>(R.id.btnToggleAutoPlay)
        val btnMakeMove = overlayView.findViewById<Button>(R.id.btnMakeMoveNow)
        val tvBestMove = overlayView.findViewById<TextView>(R.id.tvBestMove)

        btnClose.setOnClickListener {
            stopSelf()
        }

        btnAutoPlay.setOnClickListener {
            isAutoPlayActive = !isAutoPlayActive
            if (isAutoPlayActive) {
                btnAutoPlay.text = "Остановить авто-игру"
                btnAutoPlay.setBackgroundColor(getColor(R.color.red_600))
            } else {
                btnAutoPlay.text = "Включить авто-игру"
                btnAutoPlay.setBackgroundColor(getColor(R.color.emerald_600))
            }
        }

        btnMakeMove.setOnClickListener {
            executeMove(currentBestMove)
        }
    }

    private fun executeMove(moveStr: String) {
        // e.g. "e2e4"
        AutoPlayAccessibilityService.instance?.let { service ->
            // Convert algebraic coords to screen pixels based on your game board placement
            // Example coordinates:
            val startX = 300f
            val startY = 800f
            val endX = 300f
            val endY = 600f
            service.executeMoveGesture(startX, startY, endX, endY)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        engineManager.stop()
        if (::overlayView.isInitialized) {
            windowManager.removeView(overlayView)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
