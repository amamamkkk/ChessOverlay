package com.mychess.overlay

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnOverlayPermission = findViewById<Button>(R.id.btnOverlayPermission)
        val btnAccessibilityPermission = findViewById<Button>(R.id.btnAccessibilityPermission)
        val btnToggleOverlay = findViewById<Button>(R.id.btnToggleOverlay)

        // Request Overlay Permission
        btnOverlayPermission.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } else {
                Toast.makeText(this, "Разрешение на оверлей уже предоставлено!", Toast.LENGTH_SHORT).show()
            }
        }

        // Open Accessibility Settings for Auto-Play move execution
        btnAccessibilityPermission.setOnClickListener {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            startActivity(intent)
            Toast.makeText(this, "Найдите 'Chess Engine Overlay' и включите службу", Toast.LENGTH_LONG).show()
        }

        // Toggle Floating Overlay
        btnToggleOverlay.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Сначала выдайте разрешение на показ оверлея!", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            val serviceIntent = Intent(this, FloatingOverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            Toast.makeText(this, "Оверлей запущен поверх всех окон!", Toast.LENGTH_SHORT).show()
            finish() // Close settings activity so user returns to their chess game
        }
    }
}
