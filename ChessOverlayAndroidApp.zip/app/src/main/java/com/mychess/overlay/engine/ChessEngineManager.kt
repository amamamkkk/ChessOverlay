package com.mychess.overlay.engine

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.io.OutputStreamWriter

class ChessEngineManager(private val context: Context) {
    private var process: Process? = null
    private var writer: BufferedWriter? = null
    private var reader: BufferedReader? = null
    private val httpClient = OkHttpClient()

    // Download an engine binary (ARM64 executable)
    suspend fun downloadEngine(url: String, fileName: String, onProgress: (Int) -> Unit = {}): Boolean = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder().url(url).build()
            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) return@withContext false

            val body = response.body ?: return@withContext false
            val targetFile = File(context.filesDir, fileName)
            val totalBytes = body.contentLength()

            body.byteStream().use { input ->
                FileOutputStream(targetFile).use { output ->
                    val buffer = ByteArray(8192)
                    var bytesRead: Int
                    var totalRead = 0L

                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        output.write(buffer, 0, bytesRead)
                        totalRead += bytesRead
                        if (totalBytes > 0) {
                            onProgress(((totalRead * 100) / totalBytes).toInt())
                        }
                    }
                }
            }

            // Grant executable permissions (chmod 755)
            targetFile.setExecutable(true)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    // Launch binary (Stockfish, Komodo, Torch) via ProcessBuilder
    suspend fun startEngine(engineBinaryName: String = "stockfish_arm64"): Boolean = withContext(Dispatchers.IO) {
        try {
            val binaryFile = File(context.filesDir, engineBinaryName)
            if (!binaryFile.exists()) {
                // If not downloaded yet, fallback to bundled assets if present
                try {
                    context.assets.open("engines/$engineBinaryName").use { input ->
                        binaryFile.outputStream().use { output -> input.copyTo(output) }
                    }
                    binaryFile.setExecutable(true)
                } catch (e: Exception) {
                    return@withContext false
                }
            }

            val processBuilder = ProcessBuilder(binaryFile.absolutePath)
            process = processBuilder.start()

            writer = BufferedWriter(OutputStreamWriter(process!!.outputStream))
            reader = BufferedReader(InputStreamReader(process!!.inputStream))

            sendCommand("uci")
            sendCommand("isready")
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun sendCommand(cmd: String) {
        try {
            writer?.write("$cmd\n")
            writer?.flush()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Calculate best move for a given FEN string
    suspend fun calculateBestMove(fen: String, moveTimeMs: Int = 1000): String? = withContext(Dispatchers.IO) {
        try {
            sendCommand("stop")
            sendCommand("position fen $fen")
            sendCommand("go movetime $moveTimeMs")

            var line: String?
            while (reader?.readLine().also { line = it } != null) {
                line?.let {
                    if (it.startsWith("bestmove")) {
                        val parts = it.split(" ")
                        if (parts.size >= 2) {
                            return@withContext parts[1] // e.g. "e2e4"
                        }
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        null
    }

    fun stop() {
        try {
            sendCommand("quit")
            process?.destroy()
        } catch (e: Exception) {
            // Ignore
        }
    }
}
