package com.mychess.overlay.vision

import android.graphics.Bitmap

data class BoardCoordinates(
    val left: Int,
    val top: Int,
    val size: Int,
    val isFlipped: Boolean = false
)

class ChessVisionScanner {

    // Converts algebraic square (e.g. "e2") to screen (x, y) pixels
    fun squareToScreenCoords(square: String, board: BoardCoordinates): Pair<Float, Float> {
        val file = square[0] - 'a' // 0..7
        val rank = square[1] - '1' // 0..7

        val squareSize = board.size / 8f
        val col = if (board.isFlipped) 7 - file else file
        val row = if (board.isFlipped) rank else 7 - rank

        val x = board.left + (col * squareSize) + (squareSize / 2f)
        val y = board.top + (row * squareSize) + (squareSize / 2f)

        return Pair(x, y)
    }

    // Slice 8x8 squares from captured screen bitmap
    fun sliceBoard(screenBitmap: Bitmap, board: BoardCoordinates): Array<Array<Bitmap>> {
        val squareSize = board.size / 8
        return Array(8) { row ->
            Array(8) { col ->
                val x = board.left + (col * squareSize)
                val y = board.top + (row * squareSize)
                Bitmap.createBitmap(screenBitmap, x, y, squareSize, squareSize)
            }
        }
    }
}
